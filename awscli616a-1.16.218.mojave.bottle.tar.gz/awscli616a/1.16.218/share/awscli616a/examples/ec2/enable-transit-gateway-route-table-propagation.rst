**To enable a transit gateway attachment to propagate routes to the specified propagation route table**

The following ``enable-transit-gateway-route-table-propagation`` example enables the specified attachment to propagate routes to the specified propagation route table. ::

    aws ec2 enable-transit-gateway-route-table-propagation \
        --transit-gateway-route-table-id tgw-rtb-0a823edbdeEXAMPLE \
        --transit-gateway-attachment-id tgw-attach-09b52ccdb5EXAMPLE

Output::

    {
        "Propagation": {
            "TransitGatewayAttachmentId": "tgw-attach-09b52ccdb5EXAMPLE",
            "ResourceId": "vpc-4d7de228",
            "ResourceType": "vpc",
            "TransitGatewayRouteTableId": "tgw-rtb-0a823edbdeEXAMPLE",
            "State": "disabled"
        }
    }

For more information, see `Propagate a Route to a Transit Gateway Route Table <https://docs.aws.amazon.com/vpc/latest/tgw/tgw-route-tables.html#enable-tgw-route-propagation>`__ in the *AWS Transit Gateways Guide*.
